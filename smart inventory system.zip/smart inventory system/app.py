import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

if "user" not in st.session_state:
    st.session_state.user = None

if "users" not in st.session_state:
    st.session_state.users = [
        {"username": "admin", "password": "admin123", "role": "admin"}
    ]

if "products" not in st.session_state:
    st.session_state.products = [
        {"name": "Milk", "price": 100, "stock": 100, "reorder": 10},
        {"name": "Bread", "price": 50, "stock": 80, "reorder": 15}
    ]

if "sales" not in st.session_state:
    st.session_state.sales = []

if "bills" not in st.session_state:
    st.session_state.bills = []

if "cart" not in st.session_state:
    st.session_state.cart = []


def login():
    st.title("🔐 Login")

    u = st.text_input("Username")
    p = st.text_input("Password", type="password")

    if st.button("Login"):
        for user in st.session_state.users:
            if user["username"] == u and user["password"] == p:
                st.session_state.user = user
                st.success("Login Success")
                st.rerun()
                return
        st.error("Invalid credentials")


def signup():
    st.title("🧾 Signup")

    u = st.text_input("Username")
    p = st.text_input("Password")

    if st.button("Create"):
        st.session_state.users.append({
            "username": u,
            "password": p,
            "role": "user"
        })
        st.success("Account created")
 
def admin():

    st.title("👨‍💼 ADMIN DASHBOARD")

    menu = st.sidebar.selectbox(
        "Menu",
        [
            "Inventory",
            "Sales History",
            "Bills",
            "Users",
            "Daily Report",
            "Monthly Report",
            "Graph Dashboard",
            "Logout"
        ]
    )
 
    if menu == "Inventory":
        st.subheader("📦 Inventory")

        name = st.text_input("Product Name")
        price = st.number_input("Price", min_value=0.0)
        stock = st.number_input("Stock", min_value=0, step=1)
        reorder = st.number_input("Reorder Point", min_value=0, step=1)

        if st.button("Add Product"):
            st.session_state.products.append({
                "name": name,
                "price": price,
                "stock": int(stock),
                "reorder": int(reorder)
            })
            st.success("Product Added")

        for p in st.session_state.products:
            if p["stock"] <= p["reorder"]:
                st.error(f"⚠ LOW STOCK: {p['name']} ({p['stock']})")
            else:
                st.write(p)
 
    elif menu == "Sales History":
        st.subheader("📊 Sales History")
        st.dataframe(st.session_state.sales)
    elif menu == "Bills":
        st.subheader("🧾 All Bills")
        for b in st.session_state.bills:
            st.write(b) 
    elif menu == "Users":
        st.subheader("👥 Users")
        st.table(st.session_state.users)

    elif menu == "Daily Report":
        st.subheader("📅 Daily Report")

        if st.session_state.sales:
            df = pd.DataFrame(st.session_state.sales)

            df["date"] = pd.to_datetime(df["date"])

            daily = df.groupby(df["date"].dt.date)["total"].sum()

            st.bar_chart(daily)

            st.write("Total Sales Today:", df["total"].sum())
        else:
            st.info("No sales yet")

    
    elif menu == "Monthly Report":
        st.subheader("📆 Monthly Report")

        if st.session_state.sales:
            df = pd.DataFrame(st.session_state.sales)

            df["date"] = pd.to_datetime(df["date"])

            monthly = df.groupby(df["date"].dt.to_period("M"))["total"].sum()

            st.bar_chart(monthly)
        else:
            st.info("No data")

    elif menu == "Graph Dashboard":
        st.subheader("📊 Sales Graph")

        if st.session_state.sales:

            df = pd.DataFrame(st.session_state.sales)

            df["date"] = pd.to_datetime(df["date"])

            chart = df.groupby(df["date"].dt.date)["total"].sum()

            fig, ax = plt.subplots()
            chart.plot(kind="line", marker="o", ax=ax)
            ax.set_title("Sales Trend")

            st.pyplot(fig)

        else:
            st.info("No data")

    elif menu == "Logout":
        st.session_state.user = None
        st.rerun()


def user():

    st.title("🛍 USER DASHBOARD")

    menu = st.sidebar.selectbox(
        "Menu",
        ["Shop", "Cart", "My Bills", "Logout"]
    )

    if menu == "Shop":

        for i, p in enumerate(st.session_state.products):

            st.write(f"{p['name']} | Price: {p['price']}")

            qty = st.number_input(
                "Qty",
                min_value=1,
                max_value=int(p["stock"]) if p["stock"] > 0 else 1,
                value=1,
                step=1,
                key=f"q{i}"
            )

            if st.button(f"Add {p['name']}", key=f"a{i}"):

                st.session_state.cart.append({
                    "product": p["name"],
                    "qty": qty,
                    "price": p["price"]
                })

                st.success("Added")

    elif menu == "Cart":

        st.subheader("🛒 Cart")

        total = 0

        for item in st.session_state.cart:
            st.write(item)
            total += item["qty"] * item["price"]

        st.write("💰 Total:", total)

        if st.button("Generate Bill"):

            
            for item in st.session_state.cart:
                for p in st.session_state.products:
                    if p["name"] == item["product"]:
                        p["stock"] -= item["qty"]

            bill = {
                "user": st.session_state.user["username"],
                "items": st.session_state.cart,
                "total": total,
                "date": datetime.now()
            }

            st.session_state.bills.append(bill)

            st.session_state.sales.append({
                "user": st.session_state.user["username"],
                "total": total,
                "date": datetime.now()
            })

            st.success("Bill Generated")

            st.session_state.cart = []

    elif menu == "My Bills":

        for b in st.session_state.bills:
            if b["user"] == st.session_state.user["username"]:
                st.write(b)

    elif menu == "Logout":
        st.session_state.user = None
        st.rerun()


if st.session_state.user is None:

    option = st.sidebar.selectbox("Auth", ["Login", "Signup"])

    if option == "Login":
        login()
    else:
        signup()

else:

    if st.session_state.user["role"] == "admin":
        admin()
    else:
        user()