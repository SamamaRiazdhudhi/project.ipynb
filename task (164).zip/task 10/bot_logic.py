import random


MENU = {
    "pizza": "$10",
    "burger": "$5",
    "pasta": "$8",
    "coffee": "$3"
}

ORDERS = {
    "123": "Preparing ",
    "456": "Out for delivery ",
    "789": "Delivered "
}

RESERVATIONS = {
    "rehman": "Table booked for 7 PM",
    "ali": "Table booked for 9 PM"
}


def get_bot_response(message):
    msg = message.lower()

   
    if any(word in msg for word in ["hi", "hello", "hey"]):
        return "Hello! Welcome to our restaurant 🍽️ How can I help you?"

  
    elif "menu" in msg:
        menu_text = "\n".join([f"{item} - {price}" for item, price in MENU.items()])
        return f"📋 Our Menu:\n{menu_text}"

   
    elif "reservation" in msg:
        return "Please provide your name to check reservation."

    elif msg in RESERVATIONS:
        return RESERVATIONS[msg]

    
    elif "order" in msg:
        return "Please provide your order ID."

    elif msg in ORDERS:
        return f" Order Status: {ORDERS[msg]}"

   
    else:
        responses = [
            "Sorry, I didn’t understand that.",
            "Can you rephrase your question?",
            "I can help with menu, reservations, or orders."
        ]
        return random.choice(responses)