from flask import Flask, render_template, request
from datetime import datetime

app = Flask(__name__)


def generate_schedule(subjects, hours_per_day, exam_date):
    try:
        today = datetime.today()
        exam_date = datetime.strptime(exam_date, "%Y-%m-%d")

        days_left = (exam_date - today).days

        if days_left <= 0:
            return [{"day": "Error", "tasks": [" Exam date must be in future"]}]

        subjects = [s.strip() for s in subjects if s.strip()]
        if len(subjects) == 0:
            return [{"day": "Error", "tasks": [" No subjects provided"]}]

        schedule = []
        subject_index = 0

        for day in range(days_left):
            daily_tasks = []
            remaining_hours = int(hours_per_day)

            for _ in range(remaining_hours):
                subject = subjects[subject_index % len(subjects)]
                daily_tasks.append(f"{subject} - Study 1 Hour")
                subject_index += 1

            schedule.append({
                "day": f"Day {day + 1}",
                "tasks": daily_tasks
            })

        return schedule

    except Exception as e:
        return [{"day": "Error", "tasks": [str(e)]}]


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    subjects = request.form.get('subjects', '').split(',')
    exam_date = request.form.get('exam_date')
    hours_per_day = request.form.get('hours_per_day', 2)

    schedule = generate_schedule(subjects, hours_per_day, exam_date)

    return render_template('result.html', schedule=schedule)


if __name__ == "__main__":
    app.run(debug=True)