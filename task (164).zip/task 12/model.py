from sentence_transformers import SentenceTransformer
import faiss
import numpy as np


model = SentenceTransformer('all-MiniLM-L6-v2')

questions = []
answers = []


with open("data.txt", "r", encoding="utf-8") as f:
    for line in f:
        q, a = line.strip().split("::")
        questions.append(q)
        answers.append(a)


question_embeddings = model.encode(questions)


dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(np.array(question_embeddings))


def get_answer(user_query):
    query_vector = model.encode([user_query])
    
  
    D, I = index.search(np.array(query_vector), k=1)
    
    best_match = I[0][0]
    return answers[best_match]